'use strict';

angular.module('app.Services', []);
